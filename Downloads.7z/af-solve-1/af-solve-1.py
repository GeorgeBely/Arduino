import arrayfire as af

a = af.randu(3, 3)

x0 = af.randu(3, 1)
b = af.matmul(a, x0)
x1 = af.solve(a, b)

af.display(a)
af.display(b)
af.display(x1)

#############
n = 8
print("n =", n)
A = af.randu(n, n)
B = af.randu(n, 1)
X = af.solve(A, B)

af.display(A)
af.display(B)
af.display(X)