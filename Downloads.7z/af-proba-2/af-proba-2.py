"""
Test for ARRAFIRE (solve, matmul)

PROBA #2

Linux Mint 17.2
cuda 7
python 3.4
PyCharm 4.5 (Community Edition)
pycuda, ver. 2015.1.3
arrayfire, ver. 3.2.20151211
numpy, ver. 1.10.1
scipy,  ver. 0.16.1

ArrayFire v3.2.0 (OpenCL, 64-bit Linux, build c9b22d5)
[0] NVIDIA  : GeForce GT 520
None
"""
import numpy as np
from scipy import linalg
import arrayfire as af
import time
"""
One of the core functions of the time module is time(),
which returns the number of seconds since the start of
the epoch as a floating point value.
"""

L = open("af-proba-2.out", "w")  # listing

print(af.info())

gamma = 1.0
mass  = 2.0


def Dfun(i, j, nmat, lamb):
    if i == j:
        d = gamma/mass if (i == 0 or i == (nmat - 1)) else 2.0*gamma/mass
        return d - lamb
    elif abs(i-j) == 1:
        return -gamma/mass
    else:
        return 0.0


# info for af-arrays
def inf(W):
    print("elements :", W.elements(),
        "\ndtype    :", W.dtype(),
        "\nnumdims  :", W.numdims(),
        "\ndims     :", W.dims(), file=L)

n = 4096
npr =  8
print("n   =", n, "\nnpr =", npr, file=L)

lamb = 0.2

"""
print(Dfun(0, 0, n, lamb))
print(Dfun(1, 1, n, lamb))
print(Dfun(n-1, n-1, n, lamb))
print(Dfun(1, 2, n, lamb))
"""

a = np.zeros((n, n), dtype=np.float64)
for i in np.arange(n):
    for j in np.arange(i, n):
        a[i, j] = Dfun(i, j, n, lamb)
        a[j, i] = a[i, j]

b = np.random.random((n, 1))
"""
print("a\n", a[0:npr, 0:npr], file=L)
print("b\n", b[0:npr, 0], file=L)
"""
fmt = npr*"{:14.8f} "

print("a", file=L)
for i in range(npr):
    print(fmt.format(*[a[i, j] for j in range(npr)]), file=L)

print("b", file=L)
print(fmt.format(*[b[i, 0] for i in range(npr)]), file=L)

print(a.dtype.name, a.shape)
print(b.dtype.name, b.shape)

det_a = np.linalg.det(a)
print("det(a) =", det_a)
d = 1.0
for i in np.arange(n): d = d*a[i, i]
print("d =", d)

start = time.time()
# print('\nnp - Start:', start, "\n")

x = np.linalg.solve(a, b)

finish = time.time() - start
print('\nnp - Finish:', finish, "sec", file=L)
print('\nnp - Finish:', finish, "sec")

print("\nx", file=L)
print((fmt+"\n").format(*[x[i, 0] for i in range(npr)]), file=L)

print(a.dtype.name, a.shape, file=L)
print(b.dtype.name, b.shape, file=L)
print(x.dtype.name, x.shape, file=L)

######################################

start = time.time()
# print('\nnp - Start:', start, "\n")

x = linalg.solve(a, b)

finish = time.time() - start
print('\nsc - Finish:', finish, "sec", file=L)
print('\nsc - Finish:', finish, "sec")

print("\nx", file=L)
print((fmt+"\n").format(*[x[i, 0] for i in range(npr)]), file=L)

#######################################

A = af.np_to_af_array(a)
B = af.np_to_af_array(b)

print("A", file=L); inf(A)
print("B", file=L); inf(B)

fmt2 = npr*"%14.8f "

print("\nA", file=L)
for i in range(npr):
    print(fmt2 % tuple([np.array(A)[i, j] for j in range(npr)]), file=L)

print("B", file=L)
print(fmt2 % tuple([np.array(A)[i, 0] for i in range(npr)]), file=L)

start = time.time()
# print('\naf - Start:', start, "\n")

X = af.solve(A, B)

finish = time.time() - start
print('\naf - Finish:', finish, "sec", file=L)
print('\naf - Finish:', finish, "sec")

print("\nX", file=L); inf(X)
print("\nX", file=L)
print(fmt2 % tuple([np.array(X)[i] for i in range(npr)]), file=L)

# Test of solution
W = af.matmul(A, X) - B

print("\nW", file=L); inf(W)
print("\nW", file=L)
print(fmt2 % tuple([np.array(W)[i] for i in range(npr)]), file=L)
